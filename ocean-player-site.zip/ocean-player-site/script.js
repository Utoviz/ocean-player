const songs = {
  'star': 'Star song example lyrics...',
  'galaxy': 'Galaxy song example lyrics...'
};

function searchLyrics() {
  const query = document.getElementById('songInput').value.toLowerCase();
  document.getElementById('lyricsBox').textContent = songs[query] || 'No lyrics found.';
}

function randomSong() {
  const keys = Object.keys(songs);
  const pick = keys[Math.floor(Math.random()*keys.length)];
  document.getElementById('lyricsBox').textContent = songs[pick];
}
